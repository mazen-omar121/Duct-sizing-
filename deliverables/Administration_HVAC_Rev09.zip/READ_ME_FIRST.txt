ADMINISTRATION HVAC — REVISION 09

Open Administration_HVAC_Detailed_Layout_Rev09.dxf in AutoCAD.
Review paper-space layouts D001_A1 through D018_A1 and use Save As to save DWG.
Keep M-MASK enabled. VIEWPORT is a non-plotting layer. Text styles use Arial.
Print A1 PDFs at 100% / actual size to preserve stated plan scales. NTS details
must not be scaled. A monochrome print edition and color review edition are included.
Native AutoCAD plotting has not been run; compare your first plot with the PDF.

This delivery contains revised drawings, not the unchanged Rev08 package.
See REVISION_09.md for exact changes and independent_validation.json for checks.

The package includes all 85 scheduled instrument tags and drawing references,
18 detailed sheets, 4 supplementary schematic sheets, an instrument index,
11 native CAD dimensions, and the revised register workbook.

Engineering holds remain: actual pressure/transfer-air balance and outdoor air,
levels/crossing clearances, selected fitting losses/fan ESP/OEM duties, support
and insulation selections, I&C settings and approved wiring. The toilet net flow
is about -18.69 L/s and kitchen net is zero; these do not verify +25 Pa targets.
This is an engineering coordination issue; checked/approved identities are pending.

To rebuild the source: install source/requirements.txt in Python 3.12, then from
source run python cad-package/src/build_engineering_drawings.py, followed by
python cad-package/src/build_schematic.py and python cad-package/src/build_registers.py.
The included generated source copy rewrites derived schedules during rebuilding.
Preserve your edited inputs before running those generators. Rev08 and Rev09
inputs should not be mixed.
